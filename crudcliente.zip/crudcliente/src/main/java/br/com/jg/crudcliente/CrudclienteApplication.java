package br.com.jg.crudcliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudclienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudclienteApplication.class, args);
	}

}
