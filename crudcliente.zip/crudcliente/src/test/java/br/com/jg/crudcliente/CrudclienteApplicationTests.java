package br.com.jg.crudcliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
